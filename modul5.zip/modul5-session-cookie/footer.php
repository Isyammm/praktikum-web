</div>
<footer>
    <p>&copy; 2025 Praktikum Session & Cookie</p>
</footer>
</body>
</html>
