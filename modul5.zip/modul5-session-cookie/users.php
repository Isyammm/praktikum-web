<?php
// Daftar akun pengguna
$users = [
    "Admin" => "pass@admiN1",
    "Anita" => "pass@anitA2",
    "Sapta" => "pass@saptA3",
    "selfira"  => "pass@fira20" // ganti dengan akunmu sendiri
];
?>
